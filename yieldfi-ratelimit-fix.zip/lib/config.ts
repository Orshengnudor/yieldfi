import { http } from 'wagmi';
import { getDefaultConfig } from '@rainbow-me/rainbowkit';

// Define Arc testnet chain (Chain ID 5042002)
export const arcTestnet = {
  id: 5042002,
  name: 'Arc Testnet',
  nativeCurrency: { name: 'ARC', symbol: 'ARC', decimals: 18 },
  rpcUrls: {
    default: { http: ['https://rpc.testnet.arc.network'] },
    public:  { http: ['https://rpc.testnet.arc.network'] },
  },
  blockExplorers: {
    default: { name: 'ArcScan', url: 'https://scan.testnet.arc.network' },
  },
  testnet: true,
} as const;

// Arc RPC is rate-limited. Settings to stay within quota:
// - pollingInterval: 30s global (wagmi background polls)
// - batch multicall: combines multiple reads into one RPC call
// - retryCount: 2 with 1.5s delay on failures
export const config = getDefaultConfig({
  appName: 'YieldFi',
  projectId: '04d8026768c2021f104b176da04e6f11',
  chains: [arcTestnet],
  transports: {
    [arcTestnet.id]: http('https://rpc.testnet.arc.network', {
      batch: true,           // batch JSON-RPC calls where possible
      retryCount: 2,
      retryDelay: 1500,
    }),
  },
  pollingInterval: 30_000,  // 30s — prevents rate limiting
});
