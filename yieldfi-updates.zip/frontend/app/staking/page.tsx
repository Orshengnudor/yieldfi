'use client';

import { useState } from 'react';
import { useAccount } from 'wagmi';
import { useStaking, LOCK_OPTIONS } from '@/hooks/useStaking';
import ClientOnly from '../components/ClientOnly';
import StatCard from '../components/StatCard';
import { ARCSCAN_TX } from '@/lib/constants';
import { showToast, updateToast } from '../components/TxToast';

type Step = 'idle' | 'approving' | 'staking' | 'unstaking' | 'claiming' | 'done' | 'error';

function StakingContent() {
  const { isConnected, address, chainId } = useAccount();
  const onCorrectChain = chainId === 5042002;
  const [amount, setAmount] = useState('');
  const [lockIndex, setLockIndex] = useState(0);
  const [step, setStep] = useState<Step>('idle');
  const [lastTx, setLastTx] = useState('');

  const {
    yUsdcBalance,
    stakedBalance,
    earned,
    stakeCount,
    totalStaked,
    approveAndStake,
    unstake,
    claimRewards,
    formatYUsdc,
    formatUsdc,
  } = useStaking();

  const busy = ['approving', 'staking', 'unstaking', 'claiming'].includes(step);

  const handleStake = async () => {
    if (!amount || !address) return;
    const id = showToast({ type: 'pending', message: 'Approving yUSDC…' });
    setStep('approving');
    try {
      const hash = await approveAndStake(amount, LOCK_OPTIONS[lockIndex].duration);
      setStep('staking');
      updateToast(id, { type: 'success', message: 'Staked!', txHash: hash });
      setLastTx(hash);
      setAmount('');
      setStep('done');
    } catch (e: any) {
      updateToast(id, { type: 'error', message: e?.shortMessage || e?.message || 'Stake failed' });
      setStep('error');
    }
  };

  const handleUnstake = async (index: number) => {
    const id = showToast({ type: 'pending', message: `Unstaking position #${index}…` });
    setStep('unstaking');
    try {
      const hash = await unstake(index);
      updateToast(id, { type: 'success', message: 'Unstaked!', txHash: hash });
      setLastTx(hash);
      setStep('done');
    } catch (e: any) {
      updateToast(id, { type: 'error', message: e?.shortMessage || e?.message || 'Unstake failed' });
      setStep('error');
    }
  };

  const handleClaim = async () => {
    const id = showToast({ type: 'pending', message: 'Claiming rewards…' });
    setStep('claiming');
    try {
      const hash = await claimRewards();
      updateToast(id, { type: 'success', message: 'Rewards claimed!', txHash: hash });
      setLastTx(hash);
      setStep('done');
    } catch (e: any) {
      updateToast(id, { type: 'error', message: e?.shortMessage || e?.message || 'Claim failed' });
      setStep('error');
    }
  };

  if (!isConnected) {
    return (
      <div style={{ textAlign: 'center', padding: '80px 20px', color: '#a0aec0' }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>🔒</div>
        <p style={{ fontSize: 18 }}>Connect your wallet to stake yUSDC</p>
      </div>
    );
  }

  if (!onCorrectChain) {
    return (
      <div style={{ textAlign: 'center', padding: '80px 20px', color: '#f6c90e' }}>
        <p>Switch to <strong>Arc Testnet</strong> to use staking.</p>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 720, margin: '0 auto', padding: '32px 16px' }}>
      <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 8, color: '#fff' }}>Staking</h1>
      <p style={{ color: '#a0aec0', marginBottom: 32 }}>
        Stake yUSDC to earn USDC rewards + points. Longer locks = higher multiplier.
      </p>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 32 }}>
        <StatCard label="Your yUSDC" value={parseFloat(formatYUsdc(yUsdcBalance)).toFixed(4)} accentColor="purple" />
        <StatCard label="Staked"     value={parseFloat(formatYUsdc(stakedBalance)).toFixed(4)} accentColor="blue" />
        <StatCard label="Pending Rewards" value={`${parseFloat(formatUsdc(earned)).toFixed(4)} USDC`} accentColor="green" />
      </div>

      {/* Stake */}
      <div style={{
        background: 'rgba(255,255,255,0.04)',
        border: '1px solid rgba(255,255,255,0.08)',
        borderRadius: 16,
        padding: 24,
        marginBottom: 24,
      }}>
        <h2 style={{ color: '#e2e8f0', marginBottom: 16, fontSize: 18 }}>Stake yUSDC</h2>

        <div style={{ marginBottom: 16 }}>
          <label style={{ color: '#a0aec0', fontSize: 13, display: 'block', marginBottom: 6 }}>Amount (yUSDC)</label>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              type="number"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="0.00"
              style={{
                flex: 1, padding: '12px 16px',
                background: 'rgba(255,255,255,0.06)',
                border: '1px solid rgba(255,255,255,0.12)',
                borderRadius: 10, color: '#fff', fontSize: 16, outline: 'none',
              }}
            />
            <button
              onClick={() => setAmount(formatYUsdc(yUsdcBalance))}
              style={{
                padding: '12px 16px', borderRadius: 10, cursor: 'pointer',
                background: 'rgba(99,102,241,0.2)', border: '1px solid rgba(99,102,241,0.4)',
                color: '#a5b4fc', fontSize: 13, whiteSpace: 'nowrap',
              }}
            >Max</button>
          </div>
        </div>

        <div style={{ marginBottom: 20 }}>
          <label style={{ color: '#a0aec0', fontSize: 13, display: 'block', marginBottom: 8 }}>Lock Period</label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
            {LOCK_OPTIONS.map((opt, i) => (
              <button
                key={i}
                onClick={() => setLockIndex(i)}
                style={{
                  padding: '10px 14px', borderRadius: 10, cursor: 'pointer', textAlign: 'left',
                  background: lockIndex === i ? 'rgba(99,102,241,0.25)' : 'rgba(255,255,255,0.04)',
                  border: lockIndex === i ? '1px solid rgba(99,102,241,0.6)' : '1px solid rgba(255,255,255,0.1)',
                  color: lockIndex === i ? '#a5b4fc' : '#94a3b8',
                  fontSize: 13,
                }}
              >{opt.label}</button>
            ))}
          </div>
        </div>

        <button
          onClick={handleStake}
          disabled={busy || !amount}
          style={{
            width: '100%', padding: '14px 0', borderRadius: 12, cursor: busy || !amount ? 'not-allowed' : 'pointer',
            background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
            border: 'none', color: '#fff', fontSize: 16, fontWeight: 600,
            opacity: busy || !amount ? 0.6 : 1,
          }}
        >
          {step === 'approving' ? 'Approving…' : step === 'staking' ? 'Staking…' : 'Stake'}
        </button>
      </div>

      {/* Claim */}
      {earned > 0n && (
        <div style={{
          background: 'rgba(16,185,129,0.08)',
          border: '1px solid rgba(16,185,129,0.2)',
          borderRadius: 16, padding: 20, marginBottom: 24,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div>
            <div style={{ color: '#6ee7b7', fontSize: 13 }}>Claimable Rewards</div>
            <div style={{ color: '#fff', fontSize: 22, fontWeight: 700 }}>
              {parseFloat(formatUsdc(earned)).toFixed(4)} USDC
            </div>
          </div>
          <button
            onClick={handleClaim}
            disabled={busy}
            style={{
              padding: '12px 24px', borderRadius: 10, cursor: busy ? 'not-allowed' : 'pointer',
              background: 'rgba(16,185,129,0.2)', border: '1px solid rgba(16,185,129,0.4)',
              color: '#6ee7b7', fontSize: 15, fontWeight: 600,
              opacity: busy ? 0.6 : 1,
            }}
          >
            {step === 'claiming' ? 'Claiming…' : 'Claim'}
          </button>
        </div>
      )}

      {/* Active Stakes */}
      {stakeCount > 0 && (
        <div style={{
          background: 'rgba(255,255,255,0.04)',
          border: '1px solid rgba(255,255,255,0.08)',
          borderRadius: 16, padding: 24,
        }}>
          <h2 style={{ color: '#e2e8f0', marginBottom: 16, fontSize: 18 }}>Active Stakes</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {Array.from({ length: stakeCount }, (_, i) => (
              <StakePosition key={i} index={i} address={address!} onUnstake={() => handleUnstake(i)} busy={busy} formatYUsdc={formatYUsdc} />
            ))}
          </div>
        </div>
      )}

      {lastTx && (
        <div style={{ marginTop: 16, textAlign: 'center' }}>
          <a href={ARCSCAN_TX(lastTx)} target="_blank" rel="noreferrer"
            style={{ color: '#7c3aed', fontSize: 13 }}>View last tx ↗</a>
        </div>
      )}
    </div>
  );
}

// Separate component to read per-stake data
import { useReadContracts } from 'wagmi';
import { STAKING_ADDRESS } from '@/lib/constants';
import { formatUnits } from 'viem';

const STAKING_READ_ABI = [
  { type: 'function', name: 'getStake', inputs: [{ name: 'user', type: 'address' }, { name: 'index', type: 'uint256' }], outputs: [{ components: [{ name: 'amount', type: 'uint256' }, { name: 'startTime', type: 'uint256' }, { name: 'lockDuration', type: 'uint256' }, { name: 'multiplier', type: 'uint256' }], type: 'tuple' }], stateMutability: 'view' },
  { type: 'function', name: 'isUnlocked', inputs: [{ name: 'user', type: 'address' }, { name: 'index', type: 'uint256' }], outputs: [{ type: 'bool' }], stateMutability: 'view' },
  { type: 'function', name: 'timeUntilUnlock', inputs: [{ name: 'user', type: 'address' }, { name: 'index', type: 'uint256' }], outputs: [{ type: 'uint256' }], stateMutability: 'view' },
] as const;

function StakePosition({ index, address, onUnstake, busy, formatYUsdc }: {
  index: number; address: string; onUnstake: () => void; busy: boolean;
  formatYUsdc: (v: bigint) => string;
}) {
  const { data } = useReadContracts({
    contracts: [
      { address: STAKING_ADDRESS as `0x${string}`, abi: STAKING_READ_ABI, functionName: 'getStake', args: [address as `0x${string}`, BigInt(index)] },
      { address: STAKING_ADDRESS as `0x${string}`, abi: STAKING_READ_ABI, functionName: 'isUnlocked', args: [address as `0x${string}`, BigInt(index)] },
      { address: STAKING_ADDRESS as `0x${string}`, abi: STAKING_READ_ABI, functionName: 'timeUntilUnlock', args: [address as `0x${string}`, BigInt(index)] },
    ],
  });

  const stake = data?.[0]?.result as any;
  const unlocked = data?.[1]?.result as boolean | undefined;
  const timeLeft = data?.[2]?.result as bigint | undefined;

  if (!stake) return <div style={{ color: '#718096' }}>Loading position…</div>;

  const daysLeft = timeLeft ? Math.ceil(Number(timeLeft) / 86400) : 0;
  const multiplier = stake.multiplier ? Number(stake.multiplier) / 100 : 1;

  return (
    <div style={{
      background: 'rgba(255,255,255,0.04)',
      border: '1px solid rgba(255,255,255,0.08)',
      borderRadius: 12, padding: '14px 18px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16,
    }}>
      <div>
        <div style={{ color: '#fff', fontWeight: 600, fontSize: 15 }}>
          {parseFloat(formatYUsdc(stake.amount as bigint)).toFixed(4)} yUSDC
        </div>
        <div style={{ color: '#718096', fontSize: 12, marginTop: 2 }}>
          {multiplier}x multiplier · {unlocked ? '✅ Unlocked' : `🔒 ${daysLeft}d left`}
        </div>
      </div>
      <button
        onClick={onUnstake}
        disabled={busy || !unlocked}
        style={{
          padding: '8px 16px', borderRadius: 8, cursor: !unlocked || busy ? 'not-allowed' : 'pointer',
          background: unlocked ? 'rgba(239,68,68,0.15)' : 'rgba(255,255,255,0.05)',
          border: unlocked ? '1px solid rgba(239,68,68,0.4)' : '1px solid rgba(255,255,255,0.08)',
          color: unlocked ? '#fca5a5' : '#4a5568',
          fontSize: 13, fontWeight: 500,
        }}
      >Unstake</button>
    </div>
  );
}

export default function StakingPage() {
  return (
    <ClientOnly>
      <StakingContent />
    </ClientOnly>
  );
}
