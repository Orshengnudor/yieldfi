'use client';

import { useEffect, useState } from 'react';
import { useAccount } from 'wagmi';
import ClientOnly from '../components/ClientOnly';
import { getTier, Tier } from '@/lib/constants';

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3001';

const TIER_CONFIG: Record<Tier, { label: string; color: string; bg: string; emoji: string }> = {
  BRONZE:   { label: 'Bronze',   color: '#cd7f32', bg: 'rgba(205,127,50,0.15)',  emoji: '🥉' },
  SILVER:   { label: 'Silver',   color: '#c0c0c0', bg: 'rgba(192,192,192,0.15)', emoji: '🥈' },
  GOLD:     { label: 'Gold',     color: '#ffd700', bg: 'rgba(255,215,0,0.15)',   emoji: '🥇' },
  PLATINUM: { label: 'Platinum', color: '#e5e4e2', bg: 'rgba(229,228,226,0.15)', emoji: '💎' },
  CHAMPION: { label: 'Champion', color: '#a855f7', bg: 'rgba(168,85,247,0.15)',  emoji: '👑' },
};

const NEXT_TIER: Record<Tier, { tier: Tier; threshold: number } | null> = {
  BRONZE:   { tier: 'SILVER',   threshold: 500 },
  SILVER:   { tier: 'GOLD',     threshold: 2000 },
  GOLD:     { tier: 'PLATINUM', threshold: 5000 },
  PLATINUM: { tier: 'CHAMPION', threshold: 10000 },
  CHAMPION: null,
};

interface LeaderboardEntry {
  rank: number;
  address: string;
  points: number;
  tier: Tier;
}

function shortAddr(addr: string) {
  return `${addr.slice(0, 6)}…${addr.slice(-4)}`;
}

function TierBadge({ tier }: { tier: Tier }) {
  const cfg = TIER_CONFIG[tier];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '2px 10px', borderRadius: 20,
      background: cfg.bg, color: cfg.color,
      fontSize: 12, fontWeight: 600,
      border: `1px solid ${cfg.color}40`,
    }}>
      {cfg.emoji} {cfg.label}
    </span>
  );
}

function ProgressToNext({ points, tier }: { points: number; tier: Tier }) {
  const next = NEXT_TIER[tier];
  if (!next) return <div style={{ color: '#a855f7', fontSize: 13 }}>👑 Max tier reached!</div>;

  const current = points;
  const max = next.threshold;
  const pct = Math.min((current / max) * 100, 100);

  return (
    <div style={{ marginTop: 8 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>
        <span>{points} pts</span>
        <span>{next.threshold} pts for {TIER_CONFIG[next.tier].label}</span>
      </div>
      <div style={{ background: 'rgba(255,255,255,0.08)', borderRadius: 100, height: 6, overflow: 'hidden' }}>
        <div style={{
          width: `${pct}%`, height: '100%', borderRadius: 100,
          background: `linear-gradient(90deg, ${TIER_CONFIG[tier].color}, ${TIER_CONFIG[next.tier].color})`,
          transition: 'width 0.5s ease',
        }} />
      </div>
    </div>
  );
}

function LeaderboardContent() {
  const { address } = useAccount();
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [userStats, setUserStats] = useState<{ points: number; tier: Tier; rank: number | null } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch(`${BACKEND_URL}/leaderboard?limit=100`)
      .then(r => r.json())
      .then(json => { setEntries(json.data ?? []); setLoading(false); })
      .catch(() => {
        // Fallback: render empty state (backend may not be running locally)
        setLoading(false);
        setError('Backend not reachable — points are indexed from on-chain events.');
      });
  }, []);

  useEffect(() => {
    if (!address) return;
    fetch(`${BACKEND_URL}/user/${address}`)
      .then(r => r.json())
      .then(json => setUserStats({ points: json.points, tier: json.tier, rank: json.rank }))
      .catch(() => {});
  }, [address]);

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '32px 16px' }}>
      <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 8, color: '#fff' }}>Leaderboard</h1>
      <p style={{ color: '#a0aec0', marginBottom: 32 }}>
        Earn points by swapping, depositing, staking, bridging, and referring friends.
      </p>

      {/* Tier guide */}
      <div style={{
        display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 32,
        padding: '16px 20px',
        background: 'rgba(255,255,255,0.03)',
        border: '1px solid rgba(255,255,255,0.07)',
        borderRadius: 14,
      }}>
        {(Object.entries(TIER_CONFIG) as [Tier, typeof TIER_CONFIG[Tier]][]).map(([tier, cfg]) => (
          <div key={tier} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: cfg.color }}>
            <span>{cfg.emoji}</span>
            <span style={{ fontWeight: 600 }}>{cfg.label}</span>
            <span style={{ color: '#4a5568', fontSize: 11 }}>
              {tier === 'BRONZE' ? '0–499' : tier === 'SILVER' ? '500–1999' : tier === 'GOLD' ? '2000–4999' : tier === 'PLATINUM' ? '5000–9999' : '10000+'}
            </span>
          </div>
        ))}
      </div>

      {/* My stats */}
      {address && userStats && (
        <div style={{
          background: 'rgba(99,102,241,0.08)',
          border: '1px solid rgba(99,102,241,0.25)',
          borderRadius: 16, padding: '20px 24px', marginBottom: 28,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12 }}>
            <div>
              <div style={{ color: '#a5b4fc', fontSize: 13, marginBottom: 4 }}>Your Rank</div>
              <div style={{ color: '#fff', fontSize: 32, fontWeight: 800 }}>
                {userStats.rank ? `#${userStats.rank}` : '—'}
              </div>
            </div>
            <div>
              <div style={{ color: '#a5b4fc', fontSize: 13, marginBottom: 4 }}>Points</div>
              <div style={{ color: '#fff', fontSize: 32, fontWeight: 800 }}>{userStats.points.toLocaleString()}</div>
            </div>
            <div>
              <div style={{ color: '#a5b4fc', fontSize: 13, marginBottom: 4 }}>Tier</div>
              <TierBadge tier={userStats.tier} />
            </div>
          </div>
          <ProgressToNext points={userStats.points} tier={userStats.tier} />
        </div>
      )}

      {/* Table */}
      {error && (
        <div style={{ color: '#f59e0b', background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: 10, padding: '12px 16px', marginBottom: 20, fontSize: 14 }}>
          {error}
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#4a5568' }}>Loading…</div>
      ) : entries.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#4a5568' }}>
          No points recorded yet. Start swapping, depositing, or staking to appear here.
        </div>
      ) : (
        <div style={{
          background: 'rgba(255,255,255,0.03)',
          border: '1px solid rgba(255,255,255,0.07)',
          borderRadius: 16, overflow: 'hidden',
        }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'rgba(255,255,255,0.04)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                <th style={{ padding: '12px 20px', textAlign: 'left', color: '#64748b', fontSize: 12, fontWeight: 600, letterSpacing: '0.05em' }}>RANK</th>
                <th style={{ padding: '12px 20px', textAlign: 'left', color: '#64748b', fontSize: 12, fontWeight: 600 }}>ADDRESS</th>
                <th style={{ padding: '12px 20px', textAlign: 'right', color: '#64748b', fontSize: 12, fontWeight: 600 }}>POINTS</th>
                <th style={{ padding: '12px 20px', textAlign: 'right', color: '#64748b', fontSize: 12, fontWeight: 600 }}>TIER</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((e, i) => {
                const isMe = address && e.address.toLowerCase() === address.toLowerCase();
                return (
                  <tr key={e.address} style={{
                    borderBottom: '1px solid rgba(255,255,255,0.04)',
                    background: isMe ? 'rgba(99,102,241,0.08)' : 'transparent',
                    transition: 'background 0.15s',
                  }}>
                    <td style={{ padding: '14px 20px', color: i < 3 ? ['#ffd700','#c0c0c0','#cd7f32'][i] : '#64748b', fontWeight: 700, fontSize: 15 }}>
                      {i < 3 ? ['🥇','🥈','🥉'][i] : `#${e.rank}`}
                    </td>
                    <td style={{ padding: '14px 20px', color: isMe ? '#a5b4fc' : '#e2e8f0', fontFamily: 'monospace', fontSize: 14 }}>
                      {shortAddr(e.address)}
                      {isMe && <span style={{ marginLeft: 8, fontSize: 11, color: '#6366f1', background: 'rgba(99,102,241,0.15)', padding: '1px 7px', borderRadius: 10 }}>you</span>}
                    </td>
                    <td style={{ padding: '14px 20px', textAlign: 'right', color: '#fff', fontWeight: 600, fontSize: 15 }}>
                      {e.points.toLocaleString()}
                    </td>
                    <td style={{ padding: '14px 20px', textAlign: 'right' }}>
                      <TierBadge tier={e.tier} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* How to earn */}
      <div style={{
        marginTop: 32, padding: '20px 24px',
        background: 'rgba(255,255,255,0.03)',
        border: '1px solid rgba(255,255,255,0.07)',
        borderRadius: 16,
      }}>
        <h3 style={{ color: '#e2e8f0', marginBottom: 14, fontSize: 16 }}>How to earn points</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12 }}>
          {[
            { act: '🔄 Swap',     pts: '10 + 1/10 USDC' },
            { act: '🏦 Deposit',  pts: '20 + 1/10 USDC' },
            { act: '📌 Stake',    pts: '25 flat' },
            { act: '🌉 Bridge',   pts: '15 flat' },
            { act: '👥 Referral', pts: '50 flat' },
          ].map(r => (
            <div key={r.act} style={{
              background: 'rgba(255,255,255,0.04)', borderRadius: 10,
              padding: '10px 14px',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <span style={{ color: '#94a3b8', fontSize: 13 }}>{r.act}</span>
              <span style={{ color: '#a5b4fc', fontSize: 13, fontWeight: 600 }}>{r.pts}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function LeaderboardPage() {
  return (
    <ClientOnly>
      <LeaderboardContent />
    </ClientOnly>
  );
}
