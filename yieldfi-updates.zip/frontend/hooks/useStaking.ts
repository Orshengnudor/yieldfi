import { useAccount, useReadContract, useWriteContract, usePublicClient } from 'wagmi';
import { parseUnits, formatUnits } from 'viem';
import { STAKING_ADDRESS, VAULT_ADDRESS, USDC_ADDRESS, USDC_DECIMALS } from '@/lib/constants';

const VAULT_DECIMALS = 18;

const ERC20_ABI = [
  { type: 'function', name: 'balanceOf', inputs: [{ name: 'owner', type: 'address' }], outputs: [{ type: 'uint256' }], stateMutability: 'view' },
  { type: 'function', name: 'allowance', inputs: [{ name: 'owner', type: 'address' }, { name: 'spender', type: 'address' }], outputs: [{ type: 'uint256' }], stateMutability: 'view' },
  { type: 'function', name: 'approve', inputs: [{ name: 'spender', type: 'address' }, { name: 'amount', type: 'uint256' }], outputs: [{ type: 'bool' }], stateMutability: 'nonpayable' },
] as const;

const STAKING_ABI = [
  { type: 'function', name: 'stake', inputs: [{ name: 'amount', type: 'uint256' }, { name: 'lockDuration', type: 'uint256' }], outputs: [], stateMutability: 'nonpayable' },
  { type: 'function', name: 'unstake', inputs: [{ name: 'stakeIndex', type: 'uint256' }], outputs: [], stateMutability: 'nonpayable' },
  { type: 'function', name: 'claimRewards', inputs: [], outputs: [], stateMutability: 'nonpayable' },
  { type: 'function', name: 'earned', inputs: [{ name: 'user', type: 'address' }], outputs: [{ type: 'uint256' }], stateMutability: 'view' },
  { type: 'function', name: 'stakedBalance', inputs: [{ name: 'user', type: 'address' }], outputs: [{ type: 'uint256' }], stateMutability: 'view' },
  { type: 'function', name: 'stakeCount', inputs: [{ name: 'user', type: 'address' }], outputs: [{ type: 'uint256' }], stateMutability: 'view' },
  { type: 'function', name: 'getStake', inputs: [{ name: 'user', type: 'address' }, { name: 'index', type: 'uint256' }], outputs: [{ components: [{ name: 'amount', type: 'uint256' }, { name: 'startTime', type: 'uint256' }, { name: 'lockDuration', type: 'uint256' }, { name: 'multiplier', type: 'uint256' }], type: 'tuple' }], stateMutability: 'view' },
  { type: 'function', name: 'totalStaked', inputs: [], outputs: [{ type: 'uint256' }], stateMutability: 'view' },
  { type: 'function', name: 'rewardRate', inputs: [], outputs: [{ type: 'uint256' }], stateMutability: 'view' },
  { type: 'function', name: 'isUnlocked', inputs: [{ name: 'user', type: 'address' }, { name: 'index', type: 'uint256' }], outputs: [{ type: 'bool' }], stateMutability: 'view' },
  { type: 'function', name: 'timeUntilUnlock', inputs: [{ name: 'user', type: 'address' }, { name: 'index', type: 'uint256' }], outputs: [{ type: 'uint256' }], stateMutability: 'view' },
] as const;

// Lock durations in seconds → label + multiplier
export const LOCK_OPTIONS = [
  { label: 'No lock (1x)',   duration: 0,          multiplier: 100 },
  { label: '7 days (1.1x)',  duration: 7 * 86400,  multiplier: 110 },
  { label: '30 days (1.25x)',duration: 30 * 86400, multiplier: 125 },
  { label: '90 days (1.5x)', duration: 90 * 86400, multiplier: 150 },
];

export function useStaking() {
  const { address } = useAccount();
  const publicClient = usePublicClient();
  const { writeContractAsync } = useWriteContract();


  // Read balances
  const { data: yUsdcBalance, refetch: refetchBalance } = useReadContract({
    address: VAULT_ADDRESS as `0x${string}`,
    abi: ERC20_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: !!address },
  });

  const { data: yUsdcAllowance, refetch: refetchAllowance } = useReadContract({
    address: VAULT_ADDRESS as `0x${string}`,
    abi: ERC20_ABI,
    functionName: 'allowance',
    args: address ? [address, STAKING_ADDRESS as `0x${string}`] : undefined,
    query: { enabled: !!address },
  });

  const { data: stakedBalance, refetch: refetchStaked } = useReadContract({
    address: STAKING_ADDRESS as `0x${string}`,
    abi: STAKING_ABI,
    functionName: 'stakedBalance',
    args: address ? [address] : undefined,
    query: { enabled: !!address },
  });

  const { data: earned, refetch: refetchEarned } = useReadContract({
    address: STAKING_ADDRESS as `0x${string}`,
    abi: STAKING_ABI,
    functionName: 'earned',
    args: address ? [address] : undefined,
    query: { enabled: !!address },
  });

  const { data: stakeCount } = useReadContract({
    address: STAKING_ADDRESS as `0x${string}`,
    abi: STAKING_ABI,
    functionName: 'stakeCount',
    args: address ? [address] : undefined,
    query: { enabled: !!address },
  });

  const { data: totalStaked } = useReadContract({
    address: STAKING_ADDRESS as `0x${string}`,
    abi: STAKING_ABI,
    functionName: 'totalStaked',
  });

  const refetchAll = () => {
    refetchBalance();
    refetchAllowance();
    refetchStaked();
    refetchEarned();
  };

  const approveAndStake = async (amount: string, lockDuration: number) => {
    if (!address || !publicClient) throw new Error('Not connected');
    const amountBn = parseUnits(amount, VAULT_DECIMALS);
    const allowance = yUsdcAllowance ?? 0n;

    if (allowance < amountBn) {
      const hash = await writeContractAsync({
        address: VAULT_ADDRESS as `0x${string}`,
        abi: ERC20_ABI,
        functionName: 'approve',
        args: [STAKING_ADDRESS as `0x${string}`, amountBn],
      });
      await publicClient.waitForTransactionReceipt({ hash });
    }

    const hash = await writeContractAsync({
      address: STAKING_ADDRESS as `0x${string}`,
      abi: STAKING_ABI,
      functionName: 'stake',
      args: [amountBn, BigInt(lockDuration)],
    });
    await publicClient.waitForTransactionReceipt({ hash });
    refetchAll();
    return hash;
  };

  const unstake = async (stakeIndex: number) => {
    if (!address) throw new Error('Not connected');
    const hash = await writeContractAsync({
      address: STAKING_ADDRESS as `0x${string}`,
      abi: STAKING_ABI,
      functionName: 'unstake',
      args: [BigInt(stakeIndex)],
    });
    refetchAll();
    return hash;
  };

  const claimRewards = async () => {
    if (!address) throw new Error('Not connected');
    const hash = await writeContractAsync({
      address: STAKING_ADDRESS as `0x${string}`,
      abi: STAKING_ABI,
      functionName: 'claimRewards',
    });
    refetchAll();
    return hash;
  };

  return {
    yUsdcBalance: yUsdcBalance ?? 0n,
    stakedBalance: stakedBalance ?? 0n,
    earned: earned ?? 0n,
    stakeCount: Number(stakeCount ?? 0n),
    totalStaked: totalStaked ?? 0n,
    approveAndStake,
    unstake,
    claimRewards,
    formatYUsdc: (v: bigint) => formatUnits(v, VAULT_DECIMALS),
    formatUsdc: (v: bigint) => formatUnits(v, USDC_DECIMALS),
  };
}
